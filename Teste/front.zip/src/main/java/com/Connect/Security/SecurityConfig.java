package com.Connect.Security; // Pacote corrigido (estava com.Connect.d)

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Bean essencial para codificar as senhas antes de salvar no banco.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Habilita o CORS usando a configuração definida no bean corsConfigurationSource()
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))

                // 1. Desabilita a proteção CSRF (comum em APIs stateless)
                .csrf(AbstractHttpConfigurer::disable)

                // 2. Configura as regras de autorização
                .authorizeHttpRequests(auth -> auth
                        // Permite acesso total a /api/colaboradores (para o login/registro do frontend)
                        // Em um projeto real, /api/colaboradores (GET) deveria ser protegido.
                        .requestMatchers("/api/colaboradores/**").permitAll()
                        .anyRequest().authenticated() // Exige autenticação para qualquer outro endpoint
                )

                // 3. Define a política de sessão como STATELESS
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }

    /**
     * Configuração do CORS para permitir que o frontend (Vite em localhost:3232)
     * acesse a API.
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Permite requisições do frontend
        configuration.setAllowedOrigins(List.of("http://localhost:3232"));
        // Permite os métodos HTTP mais comuns
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        // Permite todos os headers
        configuration.setAllowedHeaders(List.of("*"));
        // Permite credenciais (cookies, etc.)
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        // Aplica a configuração a todos os paths da API
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}