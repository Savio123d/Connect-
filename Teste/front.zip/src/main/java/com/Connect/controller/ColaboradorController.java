package com.Connect.controller;

import com.Connect.dto.ColaboradorRequestDTO;
import com.Connect.dto.ColaboradorResponseDTO;
import com.Connect.service.ColaboradorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/colaboradores")
// O @CrossOrigin não é mais necessário aqui, pois foi configurado globalmente no SecurityConfig
public class ColaboradorController {

    private final ColaboradorService service;

    public ColaboradorController(ColaboradorService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<ColaboradorResponseDTO>> listar() {
        // Retorna a lista de DTOs (sem senhas)
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ColaboradorResponseDTO> buscarPorId(@PathVariable Long id) {
        try {
            // Retorna o DTO (sem senha)
            return ResponseEntity.ok(service.buscarPorId(id));
        } catch (RuntimeException e) {
            // Retorna 404 Not Found se o serviço lançar a exceção
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<ColaboradorResponseDTO> criar(@RequestBody ColaboradorRequestDTO dto) {
        // Recebe o RequestDTO (com senha)
        ColaboradorResponseDTO colaboradorSalvo = service.salvar(dto);

        // Retorna 201 Created e o DTO de Resposta (sem senha)
        URI location = URI.create("/api/colaboradores/" + colaboradorSalvo.getId());
        return ResponseEntity.created(location).body(colaboradorSalvo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ColaboradorResponseDTO> atualizar(@PathVariable Long id, @RequestBody ColaboradorRequestDTO dto) {
        try {
            // Recebe o RequestDTO, atualiza e retorna o ResponseDTO
            return ResponseEntity.ok(service.atualizar(id, dto));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            // Retorna 204 No Content
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}