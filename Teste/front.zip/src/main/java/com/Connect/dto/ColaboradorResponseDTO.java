package com.Connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO para enviar dados de Colaborador para o frontend.
 * IMPORTANTE: Não contém o campo 'senha' para segurança.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColaboradorResponseDTO {

    private Long id;
    private String nome;
    private String email;
    private String cpf;
    private String cargo;
    private String nivel;
    private String telefone; // O getter da entidade irá formatar este campo
    private String fotoPerfilUrl;
    private Integer idSetor;
    private Integer idGerente;
}