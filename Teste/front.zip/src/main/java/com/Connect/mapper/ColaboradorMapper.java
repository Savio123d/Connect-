package com.Connect.mapper;

import com.Connect.dto.ColaboradorRequestDTO;
import com.Connect.dto.ColaboradorResponseDTO;
import com.Connect.model.Colaborador;
import org.springframework.stereotype.Component;

/**
 * Componente para mapear Entidades Colaborador para DTOs e vice-versa.
 */
@Component
public class ColaboradorMapper {

    /**
     * Converte um RequestDTO em uma Entidade Colaborador (para salvar no banco).
     */
    public Colaborador toEntity(ColaboradorRequestDTO dto) {
        Colaborador entity = new Colaborador();
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setCpf(dto.getCpf());
        entity.setSenha(dto.getSenha()); // A senha será codificada no Service
        entity.setCargo(dto.getFuncao()); // Mapeando 'funcao' do DTO para 'cargo' da Entidade
        entity.setNivel(dto.getNivel());
        entity.setTelefone(dto.getTelefone()); // Armazena o telefone cru
        entity.setFotoPerfilUrl(dto.getFotoPerfilUrl());
        entity.setIdSetor(dto.getIdSetor());
        entity.setIdGerente(dto.getIdGerente());
        return entity;
    }

    /**
     * Converte uma Entidade Colaborador em um ResponseDTO (para enviar ao frontend).
     */
    public ColaboradorResponseDTO toResponseDTO(Colaborador entity) {
        ColaboradorResponseDTO dto = new ColaboradorResponseDTO();
        dto.setId(entity.getId());
        dto.setNome(entity.getNome());
        dto.setEmail(entity.getEmail());
        dto.setCpf(entity.getCpf());
        dto.setCargo(entity.getCargo());
        dto.setNivel(entity.getNivel());
        dto.setTelefone(entity.getTelefone()); // O getTelefone() da entidade já retorna formatado
        dto.setFotoPerfilUrl(entity.getFotoPerfilUrl());
        dto.setIdSetor(entity.getIdSetor());
        dto.setIdGerente(entity.getIdGerente());
        return dto;
    }

    /**
     * Atualiza uma Entidade existente com dados de um DTO (para o método PUT).
     */
    public void updateEntityFromDTO(ColaboradorRequestDTO dto, Colaborador entity) {
        // Atualiza apenas os campos permitidos
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setCpf(dto.getCpf());
        entity.setCargo(dto.getFuncao());
        entity.setNivel(dto.getNivel());
        entity.setTelefone(dto.getTelefone());
        entity.setFotoPerfilUrl(dto.getFotoPerfilUrl());
        entity.setIdSetor(dto.getIdSetor());
        entity.setIdGerente(dto.getIdGerente());

        // A senha só deve ser atualizada se fornecida (lógica no Service)
    }
}