package com.Connect.model;

import com.Connect.Utilidades.TelefoneUtil;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "colaborador") // Mapeamento explícito para a tabela do SQL
@Data // Adiciona getters, setters, toString, etc. (Lombok)
@NoArgsConstructor
@AllArgsConstructor
public class Colaborador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_colaborador") // Mapeado para o .sql
    private Long id;

    @Column(name = "id_setor") // Mapeado para o .sql
    private Integer idSetor;

    @Column(name = "id_gerente") // Mapeado para o .sql
    private Integer idGerente;

    @Column(name = "nome", nullable = false) // Mapeado para o .sql
    private String nome;

    @Column(name = "email", nullable = false, unique = true) // Mapeado para o .sql
    private String email;

    @Column(name = "senha", nullable = false) // Mapeado para o .sql
    private String senha;

    @Column(name = "cargo") // Mapeado para o .sql
    private String cargo;

    @Column(name = "telefone") // Mapeado para o .sql
    private String telefone; // Armazena o valor cru (sem formatação)

    @Column(name = "foto_perfil_url") // Mapeado para o .sql
    private String fotoPerfilUrl;

    // Campos do register.jsx que não estavam no .java mas são necessários
    @Column(name = "cpf", unique = true)
    private String cpf;

    @Column(name = "nivel")
    private String nivel; // "Colaborador" ou "Gerente"

    public String getTelefone() {
        return TelefoneUtil.formatar(this.telefone);
    }

}